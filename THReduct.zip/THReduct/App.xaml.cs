using System.Linq;
using System.Threading;
using System.Windows;

namespace THReduct
{
    public partial class App : Application
    {
        Mutex? _mutex;

        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            _mutex = new Mutex(true, "THReduct_SingleInstance", out bool created);
            if (!created) { Shutdown(); return; }

            MemoryCleaner.EnablePrivileges();

            var settings = Settings.Load();
            Loc.Apply(settings.Language);
            ThemeManager.Apply(settings);
            bool hidden = e.Args.Contains("--tray") && settings.StartMinimized;

            var window = new MainWindow();
            if (!hidden) window.Show();
        }
    }
}
