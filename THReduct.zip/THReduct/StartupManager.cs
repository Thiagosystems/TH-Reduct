using System;
using System.Diagnostics;
using System.IO;
using System.Security;
using System.Security.Principal;
using System.Text;

namespace THReduct
{
    /// <summary>
    /// Usa o Agendador de Tarefas (com privilégio elevado), pois apps que exigem
    /// administrador são bloqueados pelo UAC na chave Run do registro.
    /// </summary>
    internal static class StartupManager
    {
        const string TaskName = "TH Reduct";

        public static void Set(bool enabled)
        {
            try
            {
                if (!enabled)
                {
                    Run($"/Delete /F /TN \"{TaskName}\"");
                    return;
                }

                string exe = SecurityElement.Escape(Environment.ProcessPath!)!;
                string user = SecurityElement.Escape(WindowsIdentity.GetCurrent().Name)!;
                string xml = $@"<?xml version=""1.0"" encoding=""UTF-16""?>
<Task version=""1.2"" xmlns=""http://schemas.microsoft.com/windows/2004/02/mit/task"">
  <Triggers><LogonTrigger><Enabled>true</Enabled><UserId>{user}</UserId></LogonTrigger></Triggers>
  <Principals><Principal id=""Author""><UserId>{user}</UserId><LogonType>InteractiveToken</LogonType><RunLevel>HighestAvailable</RunLevel></Principal></Principals>
  <Settings>
    <DisallowStartIfOnBatteries>false</DisallowStartIfOnBatteries>
    <StopIfGoingOnBatteries>false</StopIfGoingOnBatteries>
    <ExecutionTimeLimit>PT0S</ExecutionTimeLimit>
    <MultipleInstancesPolicy>IgnoreNew</MultipleInstancesPolicy>
  </Settings>
  <Actions Context=""Author""><Exec><Command>{exe}</Command><Arguments>--tray</Arguments></Exec></Actions>
</Task>";
                string tmp = Path.Combine(Path.GetTempPath(), "threduct_task.xml");
                File.WriteAllText(tmp, xml, Encoding.Unicode);
                Run($"/Create /F /TN \"{TaskName}\" /XML \"{tmp}\"");
                File.Delete(tmp);
            }
            catch { }
        }

        static void Run(string args)
        {
            using var p = Process.Start(new ProcessStartInfo("schtasks.exe", args)
            {
                CreateNoWindow = true,
                UseShellExecute = false
            });
            p?.WaitForExit(5000);
        }
    }
}
