using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace THReduct
{
    internal static class IconFactory
    {
        static readonly Uri IcoUri = new("pack://application:,,,/Assets/app.ico");

        /// <summary>Ícone da bandeja com a % de uso, colorido conforme a carga.</summary>
        public static Icon Percent(int pct)
        {
            using var bmp = new Bitmap(32, 32);
            using (var g = Graphics.FromImage(bmp))
            {
                g.SmoothingMode = SmoothingMode.AntiAlias;
                g.TextRenderingHint = TextRenderingHint.AntiAliasGridFit;

                System.Drawing.Color bg, fg;
                if (pct >= 85) { bg = System.Drawing.Color.FromArgb(239, 68, 68); fg = System.Drawing.Color.White; }
                else if (pct >= 65) { bg = System.Drawing.Color.FromArgb(245, 158, 11); fg = System.Drawing.Color.FromArgb(11, 14, 26); }
                else { bg = System.Drawing.Color.FromArgb(34, 211, 238); fg = System.Drawing.Color.FromArgb(11, 14, 26); }

                using var path = Rounded(new RectangleF(0, 0, 32, 32), 9);
                using var br = new SolidBrush(bg);
                g.FillPath(br, path);

                string text = Math.Min(pct, 99).ToString();
                using var font = new Font("Segoe UI", 19f, System.Drawing.FontStyle.Bold, GraphicsUnit.Pixel);
                using var sf = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center };
                using var tb = new SolidBrush(fg);
                g.DrawString(text, font, tb, new RectangleF(0, 1, 32, 32), sf);
            }
            IntPtr h = bmp.GetHicon();
            try { return (Icon)Icon.FromHandle(h).Clone(); }
            finally { Native.DestroyIcon(h); }
        }

        /// <summary>Logo TH (Assets/app.ico) para a bandeja.</summary>
        public static Icon Logo()
        {
            var info = System.Windows.Application.GetResourceStream(IcoUri);
            using var s = info.Stream;
            return new Icon(s, 32, 32);
        }

        /// <summary>Logo TH para o ícone da janela.</summary>
        public static ImageSource LogoSource() => BitmapFrame.Create(IcoUri);

        static GraphicsPath Rounded(RectangleF r, float radius)
        {
            float d = radius * 2;
            var p = new GraphicsPath();
            p.AddArc(r.X, r.Y, d, d, 180, 90);
            p.AddArc(r.Right - d, r.Y, d, d, 270, 90);
            p.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
            p.AddArc(r.X, r.Bottom - d, d, d, 90, 90);
            p.CloseFigure();
            return p;
        }
    }
}
