using System;
using System.Windows;
using System.Windows.Interop;

namespace THReduct
{
    /// <summary>Widget flutuante, sempre no topo e "transparente ao clique" (não atrapalha o jogo).</summary>
    public partial class OverlayWindow : Window
    {
        const int GWL_EXSTYLE = -20;
        const long WS_EX_TRANSPARENT = 0x20, WS_EX_TOOLWINDOW = 0x80, WS_EX_LAYERED = 0x80000, WS_EX_NOACTIVATE = 0x08000000;

        int _corner = 1;
        IntPtr _hwnd;

        public OverlayWindow()
        {
            InitializeComponent();
            SourceInitialized += (_, _) =>
            {
                _hwnd = new WindowInteropHelper(this).Handle;
                long ex = Native.GetWindowLongPtr(_hwnd, GWL_EXSTYLE).ToInt64();
                Native.SetWindowLongPtr(_hwnd, GWL_EXSTYLE,
                    new IntPtr(ex | WS_EX_TRANSPARENT | WS_EX_TOOLWINDOW | WS_EX_LAYERED | WS_EX_NOACTIVATE));
            };
            SizeChanged += (_, _) => Place();
        }

        public void SetCorner(int corner)
        {
            _corner = corner;
            Place();
        }

        void Place()
        {
            var wa = SystemParameters.WorkArea;
            const double m = 12;
            Left = _corner % 2 == 0 ? wa.Left + m : wa.Right - ActualWidth - m;
            Top = _corner < 2 ? wa.Top + m : wa.Bottom - ActualHeight - m;
        }

        public void Update(int ramPct, string? extra, string? game)
        {
            TxtRam.Text = $"RAM {ramPct}%";
            TxtExtra.Text = extra ?? "";
            TxtExtra.Visibility = string.IsNullOrEmpty(extra) ? Visibility.Collapsed : Visibility.Visible;
            TxtGame.Text = game ?? "";
            TxtGame.Visibility = string.IsNullOrEmpty(game) ? Visibility.Collapsed : Visibility.Visible;

            // Reafirma "sempre no topo" (alguns jogos tomam a frente)
            if (_hwnd != IntPtr.Zero)
                Native.SetWindowPos(_hwnd, new IntPtr(-1), 0, 0, 0, 0, 0x0001 | 0x0002 | 0x0010);
        }
    }
}
