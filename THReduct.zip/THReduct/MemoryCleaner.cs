using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading;

namespace THReduct
{
    public static class MemoryCleaner
    {
        const int SystemMemoryListInformation = 80;
        const int MemoryEmptyWorkingSets = 2;
        const int MemoryFlushModifiedList = 3;
        const int MemoryPurgeStandbyList = 4;
        const int MemoryPurgeLowPriorityStandbyList = 5;

        public static (ulong Total, ulong Avail, uint Load) GetStatus()
        {
            var m = new Native.MEMORYSTATUSEX { dwLength = (uint)Marshal.SizeOf<Native.MEMORYSTATUSEX>() };
            Native.GlobalMemoryStatusEx(ref m);
            return (m.ullTotalPhys, m.ullAvailPhys, m.dwMemoryLoad);
        }

        /// <summary>Memória virtual (commit): usada e limite (RAM + arquivo de paginação).</summary>
        public static (ulong Used, ulong Limit) GetCommit()
        {
            var pi = new Native.PERFORMANCE_INFORMATION { cb = (uint)Marshal.SizeOf<Native.PERFORMANCE_INFORMATION>() };
            if (!Native.GetPerformanceInfo(ref pi, (int)pi.cb)) return (0, 0);
            ulong page = (ulong)pi.PageSize;
            return ((ulong)pi.CommitTotal * page, (ulong)pi.CommitLimit * page);
        }

        public static void EnablePrivileges()
        {
            Enable("SeProfileSingleProcessPrivilege");
            Enable("SeIncreaseQuotaPrivilege");
            Enable("SeDebugPrivilege");
        }

        static void Enable(string name)
        {
            const uint TOKEN_ADJUST_PRIVILEGES = 0x20, TOKEN_QUERY = 0x8, SE_PRIVILEGE_ENABLED = 0x2;
            if (!Native.OpenProcessToken(Native.GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, out var token)) return;
            try
            {
                if (!Native.LookupPrivilegeValue(null, name, out var luid)) return;
                var tp = new Native.TOKEN_PRIVILEGES { Count = 1, Luid = luid, Attributes = SE_PRIVILEGE_ENABLED };
                Native.AdjustTokenPrivileges(token, false, ref tp, 0, IntPtr.Zero, IntPtr.Zero);
            }
            finally { Native.CloseHandle(token); }
        }

        /// <summary>Executa a limpeza e retorna quantos bytes foram liberados.</summary>
        public static long Clean(Settings s)
        {
            ulong before = GetStatus().Avail;

            if (s.WorkingSet) EmptyWorkingSets();
            if (s.SystemCache) Native.SetSystemFileCacheSize(new UIntPtr(ulong.MaxValue), new UIntPtr(ulong.MaxValue), 0);
            if (s.ModifiedList) Command(MemoryFlushModifiedList);
            if (s.StandbyList) Command(MemoryPurgeStandbyList);
            else if (s.StandbyLowPriority) Command(MemoryPurgeLowPriorityStandbyList);

            Thread.Sleep(300);
            ulong after = GetStatus().Avail;
            return (long)after - (long)before;
        }

        /// <summary>Esvazia o working set de um único processo. Retorna bytes liberados.</summary>
        public static long CleanProcess(int pid)
        {
            try
            {
                using var p = Process.GetProcessById(pid);
                long before = p.WorkingSet64;
                Native.EmptyWorkingSet(p.Handle);
                p.Refresh();
                return Math.Max(0, before - p.WorkingSet64);
            }
            catch { return 0; }
        }

        public static void PurgeLowPriorityStandby() => Command(MemoryPurgeLowPriorityStandbyList);

        /// <summary>Lista de processos ordenada pelo uso de RAM (working set).</summary>
        public static List<(int Pid, string Name, long Bytes)> TopProcesses(int count)
        {
            var list = new List<(int, string, long)>();
            int self = Environment.ProcessId;
            foreach (var p in Process.GetProcesses())
            {
                try
                {
                    if (p.Id > 4 && p.Id != self) list.Add((p.Id, p.ProcessName, p.WorkingSet64));
                }
                catch { }
                finally { p.Dispose(); }
            }
            return list.OrderByDescending(x => x.Item3).Take(count).ToList();
        }

        static int Command(int cmd)
        {
            int v = cmd;
            return Native.NtSetSystemInformation(SystemMemoryListInformation, ref v, sizeof(int));
        }

        static void EmptyWorkingSets()
        {
            if (Command(MemoryEmptyWorkingSets) == 0) return;

            foreach (var p in Process.GetProcesses())
            {
                try { Native.EmptyWorkingSet(p.Handle); }
                catch { }
                finally { p.Dispose(); }
            }
        }
    }
}
