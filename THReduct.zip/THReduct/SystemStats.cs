using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;

namespace THReduct
{
    /// <summary>CPU, GPU e temperatura (melhor esforço — nem todo PC expõe GPU/temperatura).</summary>
    public sealed class SystemStats
    {
        long _pIdle, _pKernel, _pUser;
        List<PerformanceCounter>? _gpu;
        DateTime _gpuRefresh;
        PerformanceCounter[]? _thermal;
        bool _thermalTried;

        public double Cpu { get; private set; }
        public double? Gpu { get; private set; }
        public double? TempC { get; private set; }

        /// <summary>Chamar a cada ~1 s, fora da thread da interface.</summary>
        public void Update(bool extra)
        {
            if (Native.GetSystemTimes(out long idle, out long kernel, out long user))
            {
                long dIdle = idle - _pIdle, total = (kernel - _pKernel) + (user - _pUser);
                if (_pKernel != 0 && total > 0)
                    Cpu = Math.Clamp((total - dIdle) * 100.0 / total, 0, 100);
                _pIdle = idle; _pKernel = kernel; _pUser = user;
            }

            if (!extra) return;
            UpdateGpu();
            UpdateTemp();
        }

        void UpdateGpu()
        {
            try
            {
                if (_gpu == null || (DateTime.Now - _gpuRefresh).TotalSeconds > 10)
                {
                    _gpu?.ForEach(c => c.Dispose());
                    var cat = new PerformanceCounterCategory("GPU Engine");
                    _gpu = cat.GetInstanceNames()
                              .Where(n => n.EndsWith("engtype_3D", StringComparison.OrdinalIgnoreCase))
                              .Select(n => new PerformanceCounter("GPU Engine", "Utilization Percentage", n, true))
                              .ToList();
                    foreach (var c in _gpu) { try { c.NextValue(); } catch { } }
                    _gpuRefresh = DateTime.Now;
                    return; // primeira leitura é sempre 0
                }

                double sum = 0;
                foreach (var c in _gpu) { try { sum += c.NextValue(); } catch { } }
                Gpu = Math.Min(100, sum);
            }
            catch { Gpu = null; }
        }

        void UpdateTemp()
        {
            try
            {
                if (!_thermalTried)
                {
                    _thermalTried = true;
                    var cat = new PerformanceCounterCategory("Thermal Zone Information");
                    _thermal = cat.GetInstanceNames()
                                  .Select(n => new PerformanceCounter("Thermal Zone Information", "Temperature", n, true))
                                  .ToArray();
                }
                if (_thermal == null || _thermal.Length == 0) { TempC = null; return; }

                double max = 0;
                foreach (var t in _thermal) { try { max = Math.Max(max, t.NextValue()); } catch { } }
                TempC = max > 200 ? max - 273.15 : null; // valor vem em Kelvin
            }
            catch { TempC = null; }
        }
    }
}
