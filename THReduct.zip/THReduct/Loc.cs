using System.Collections.Generic;
using System.Windows;

namespace THReduct
{
    /// <summary>
    /// Traduções (Português / English / Español).
    /// Textos da interface usam {DynamicResource T_Chave}; o código usa Loc.T("T_Chave").
    /// Para adicionar um idioma, acrescente uma coluna em cada linha e trate o código em Index().
    /// </summary>
    public static class Loc
    {
        public static string Lang { get; private set; } = "pt";

        static int Index() => Lang switch { "en" => 1, "es" => 2, _ => 0 };

        static readonly Dictionary<string, string[]> D = new()
        {
            // ---------- Janela / principal ----------
            ["T_Settings"]     = new[] { "Configurações", "Settings", "Configuración" },
            ["T_Back"]         = new[] { "Voltar", "Back", "Volver" },
            ["T_Minimize"]     = new[] { "Minimizar", "Minimize", "Minimizar" },
            ["T_CloseTray"]    = new[] { "Fechar para a bandeja", "Close to tray", "Cerrar a la bandeja" },
            ["T_InUseCaption"] = new[] { "memória em uso", "memory in use", "memoria en uso" },
            ["T_Used"]         = new[] { "Em uso", "Used", "En uso" },
            ["T_Free"]         = new[] { "Livre", "Free", "Libre" },
            ["T_Total"]        = new[] { "Total", "Total", "Total" },
            ["T_Last5"]        = new[] { "Últimos 5 min", "Last 5 min", "Últimos 5 min" },
            ["T_Virtual"]      = new[] { "Virtual: {0} / {1}", "Virtual: {0} / {1}", "Virtual: {0} / {1}" },
            ["T_VirtualTip"]   = new[] { "Memória virtual em uso (RAM + arquivo de paginação) / limite",
                                         "Virtual memory in use (RAM + page file) / limit",
                                         "Memoria virtual en uso (RAM + archivo de paginación) / límite" },
            ["T_Clean"]        = new[] { "Limpar memória", "Clean memory", "Liberar memoria" },
            ["T_Cleaning"]     = new[] { "Limpando...", "Cleaning...", "Liberando..." },
            ["T_Ready"]        = new[] { "Pronto para limpar", "Ready to clean", "Listo para liberar" },
            ["T_Freed"]        = new[] { "Liberado {0} às {1}", "Freed {0} at {1}", "Liberado {0} a las {1}" },
            ["T_AutoSuffix"]   = new[] { " (auto)", " (auto)", " (auto)" },
            ["T_Error"]        = new[] { "Erro: {0}", "Error: {0}", "Error: {0}" },
            ["T_GamePrioritized"] = new[] { "{0}.exe priorizado", "{0}.exe prioritized", "{0}.exe priorizado" },

            // ---------- Abas ----------
            ["T_TabClean"]  = new[] { "Limpeza", "Cleaning", "Limpieza" },
            ["T_TabAuto"]   = new[] { "Automático e avisos", "Automatic & alerts", "Automático y avisos" },
            ["T_TabGame"]   = new[] { "Modo jogo", "Game mode", "Modo juego" },
            ["T_TabProc"]   = new[] { "Processos", "Processes", "Procesos" },
            ["T_TabHist"]   = new[] { "Histórico", "History", "Historial" },
            ["T_TabWidget"] = new[] { "Widget", "Widget", "Widget" },
            ["T_TabLook"]   = new[] { "Visual", "Appearance", "Apariencia" },
            ["T_TabSys"]    = new[] { "Sistema", "System", "Sistema" },

            // ---------- Limpeza ----------
            ["T_SecAreas"]    = new[] { "ÁREAS DE LIMPEZA", "CLEANING AREAS", "ÁREAS DE LIMPIEZA" },
            ["T_WorkingSet"]  = new[] { "Working set dos processos", "Process working sets", "Working set de procesos" },
            ["T_SysCache"]    = new[] { "Cache de arquivos do sistema", "System file cache", "Caché de archivos del sistema" },
            ["T_Modified"]    = new[] { "Páginas modificadas", "Modified page list", "Páginas modificadas" },
            ["T_Standby"]     = new[] { "Lista standby", "Standby list", "Lista standby" },
            ["T_StandbyLow"]  = new[] { "Standby (só baixa prioridade)", "Standby (low priority only)", "Standby (solo baja prioridad)" },

            // ---------- Automático / avisos ----------
            ["T_SecAuto"]      = new[] { "LIMPEZA AUTOMÁTICA", "AUTOMATIC CLEANING", "LIMPIEZA AUTOMÁTICA" },
            ["T_AutoWhen"]     = new[] { "Quando passar de {0}%", "When above {0}%", "Cuando supere {0}%" },
            ["T_AutoEvery"]    = new[] { "A cada {0} min", "Every {0} min", "Cada {0} min" },
            ["T_SecAlerts"]    = new[] { "AVISOS", "ALERTS", "AVISOS" },
            ["T_LowRam"]       = new[] { "Avisar quando a RAM passar de {0}%", "Warn when RAM is above {0}%", "Avisar cuando la RAM supere {0}%" },
            ["T_ProcAlertLbl"] = new[] { "Avisar se um app usar mais de {0}", "Warn if an app uses more than {0}", "Avisar si una app usa más de {0}" },
            ["T_LowRamMsg"]    = new[] { "RAM quase cheia ({0}%). Clique aqui para limpar.",
                                         "RAM almost full ({0}%). Click here to clean.",
                                         "RAM casi llena ({0}%). Haz clic aquí para liberar." },
            ["T_ProcAlertMsg"] = new[] { "{0}.exe está usando {1} de RAM. Clique para liberar.",
                                         "{0}.exe is using {1} of RAM. Click to free it.",
                                         "{0}.exe está usando {1} de RAM. Haz clic para liberar." },

            // ---------- Modo jogo ----------
            ["T_GameEnable"]    = new[] { "Ativar modo jogo", "Enable game mode", "Activar modo juego" },
            ["T_GameDetect"]    = new[] { "Detectar jogos da Steam, Epic e Riot", "Detect Steam, Epic and Riot games", "Detectar juegos de Steam, Epic y Riot" },
            ["T_SecMyGames"]    = new[] { "MEUS JOGOS", "MY GAMES", "MIS JUEGOS" },
            ["T_GameExeTip"]    = new[] { "Nome do .exe do jogo (ex: cs2)", "Game .exe name (e.g. cs2)", "Nombre del .exe del juego (ej: cs2)" },
            ["T_Open"]          = new[] { "Abertos ▾", "Running ▾", "Abiertos ▾" },
            ["T_Add"]           = new[] { "Adicionar jogo", "Add game", "Añadir juego" },
            ["T_GameAutoRow"]   = new[] { "Detectados automaticamente", "Auto-detected games", "Detectados automáticamente" },
            ["T_GameRemove"]    = new[] { "Remover", "Remove", "Quitar" },
            ["T_GameConfig"]    = new[] { "CONFIGURAÇÃO — {0}", "SETTINGS — {0}", "CONFIGURACIÓN — {0}" },
            ["T_GameClean"]     = new[] { "Limpar memória quando abrir", "Clean memory on launch", "Liberar memoria al abrir" },
            ["T_GamePower"]     = new[] { "Plano de energia Alto desempenho", "High performance power plan", "Plan de energía Alto rendimiento" },
            ["T_HeavyApps"]     = new[] { "Apps pesados", "Heavy apps", "Apps pesadas" },
            ["T_HeavyNone"]     = new[] { "Nada", "None", "Nada" },
            ["T_HeavyPause"]    = new[] { "Pausar", "Pause", "Pausar" },
            ["T_HeavyClose"]    = new[] { "Fechar", "Close", "Cerrar" },
            ["T_HeavyListTip"]  = new[] { "Apps pesados, separados por vírgula. Pausados voltam quando o jogo fecha.",
                                          "Heavy apps, comma separated. Paused apps resume when the game closes.",
                                          "Apps pesadas, separadas por coma. Las pausadas se reanudan al cerrar el juego." },
            ["T_Trim"]          = new[] { "Liberar RAM dos outros apps a cada {0} s", "Free other apps' RAM every {0} s", "Liberar RAM de otras apps cada {0} s" },
            ["T_GameOff"]       = new[] { "Desativado", "Disabled", "Desactivado" },
            ["T_GameWaiting"]   = new[] { "Aguardando um jogo abrir...", "Waiting for a game...", "Esperando un juego..." },
            ["T_GameActive"]    = new[] { "{0}.exe priorizado", "{0}.exe prioritized", "{0}.exe priorizado" },
            ["T_GameDetected"]  = new[] { "{0}.exe detectado — RAM priorizada para o jogo.", "{0}.exe detected — RAM prioritized for the game.", "{0}.exe detectado — RAM priorizada para el juego." },
            ["T_NoWindows"]     = new[] { "Nenhum app com janela aberto", "No windowed apps running", "No hay apps con ventana abiertas" },

            // ---------- Processos ----------
            ["T_SecProc"]      = new[] { "APPS QUE MAIS USAM RAM", "TOP RAM USAGE", "APPS QUE MÁS RAM USAN" },
            ["T_ProcCleanBtn"] = new[] { "Limpar", "Clean", "Liberar" },
            ["T_ProcFreed"]    = new[] { "{0}.exe: liberado {1}", "{0}.exe: freed {1}", "{0}.exe: liberado {1}" },

            // ---------- Histórico ----------
            ["T_SecHist"]      = new[] { "HISTÓRICO DE LIMPEZAS", "CLEANING HISTORY", "HISTORIAL DE LIMPIEZAS" },
            ["T_HistSummary"]  = new[] { "Hoje: {0} limpezas · {1} liberados\nTotal: {2}", "Today: {0} cleanings · {1} freed\nTotal: {2}", "Hoy: {0} limpiezas · {1} liberados\nTotal: {2}" },
            ["T_HistEmpty"]    = new[] { "Nenhuma limpeza ainda.", "No cleanings yet.", "Aún no hay limpiezas." },
            ["T_HistClear"]    = new[] { "Apagar histórico", "Clear history", "Borrar historial" },
            ["T_KManual"]      = new[] { "Manual", "Manual", "Manual" },
            ["T_KAuto"]        = new[] { "Automática", "Automatic", "Automática" },
            ["T_KGame"]        = new[] { "Modo jogo", "Game mode", "Modo juego" },
            ["T_KHotkey"]      = new[] { "Atalho", "Hotkey", "Atajo" },
            ["T_KProcess"]     = new[] { "Processo", "Process", "Proceso" },

            // ---------- Widget ----------
            ["T_SecWidget"]      = new[] { "WIDGET FLUTUANTE", "FLOATING WIDGET", "WIDGET FLOTANTE" },
            ["T_WidgetShow"]     = new[] { "Mostrar widget", "Show widget", "Mostrar widget" },
            ["T_WidgetGameOnly"] = new[] { "Só durante o jogo", "Only while gaming", "Solo durante el juego" },
            ["T_WidgetExtra"]    = new[] { "Mostrar CPU, GPU e temperatura", "Show CPU, GPU and temperature", "Mostrar CPU, GPU y temperatura" },
            ["T_SecPosition"]    = new[] { "POSIÇÃO", "POSITION", "POSICIÓN" },
            ["T_WidgetNote"]     = new[] { "Aparece por cima de jogos em janela ou tela cheia sem bordas. O FPS não é exibido porque medir exige injetar código no jogo, o que pode causar ban por anti-cheat. A temperatura depende do sensor ACPI do PC.",
                                           "Shows over windowed or borderless fullscreen games. FPS is not shown because measuring it requires injecting code into the game, which can trigger anti-cheat bans. Temperature depends on the PC's ACPI sensor.",
                                           "Aparece sobre juegos en ventana o pantalla completa sin bordes. No se muestra el FPS porque medirlo requiere inyectar código en el juego, lo que puede causar baneo por anti-cheat. La temperatura depende del sensor ACPI del PC." },
            ["T_NA"]             = new[] { "n/d", "n/a", "n/d" },

            // ---------- Visual ----------
            ["T_SecTheme"]   = new[] { "TEMA", "THEME", "TEMA" },
            ["T_ThemeDark"]  = new[] { "Escuro", "Dark", "Oscuro" },
            ["T_ThemeBlack"] = new[] { "Preto", "Black", "Negro" },
            ["T_ThemeLight"] = new[] { "Claro", "Light", "Claro" },
            ["T_SecAccent"]  = new[] { "COR DE DESTAQUE", "ACCENT COLOR", "COLOR DE ACENTO" },
            ["T_PickTip"]    = new[] { "Clique para escolher a cor", "Click to pick a color", "Haz clic para elegir el color" },
            ["T_SecLogo"]    = new[] { "LOGO", "LOGO", "LOGO" },
            ["T_LogoAccent"] = new[] { "Usar a cor de destaque", "Use accent color", "Usar el color de acento" },
            ["T_Size"]       = new[] { "Tamanho: {0}%", "Size: {0}%", "Tamaño: {0}%" },

            // ---------- Sistema ----------
            ["T_SecLang"]      = new[] { "IDIOMA", "LANGUAGE", "IDIOMA" },
            ["T_SecHotkey"]    = new[] { "ATALHO PARA LIMPAR", "CLEAN HOTKEY", "ATAJO PARA LIBERAR" },
            ["T_HotkeyEnable"] = new[] { "Ativar atalho", "Enable hotkey", "Activar atajo" },
            ["T_HotkeyTip"]    = new[] { "Clique e pressione a combinação (ex: Ctrl+Shift+L)", "Click and press the combination (e.g. Ctrl+Shift+L)", "Haz clic y pulsa la combinación (ej: Ctrl+Shift+L)" },
            ["T_HotkeyPress"]  = new[] { "Pressione...", "Press keys...", "Pulsa..." },
            ["T_HotkeyFail"]   = new[] { "Esse atalho já está em uso por outro programa.", "This hotkey is already used by another program.", "Ese atajo ya lo usa otro programa." },
            ["T_SecSystem"]    = new[] { "SISTEMA", "SYSTEM", "SISTEMA" },
            ["T_Startup"]      = new[] { "Iniciar com o Windows", "Start with Windows", "Iniciar con Windows" },
            ["T_StartMin"]     = new[] { "Iniciar minimizado na bandeja", "Start minimized to tray", "Iniciar minimizado en la bandeja" },
            ["T_TrayPct"]      = new[] { "Mostrar % no ícone da bandeja", "Show % on tray icon", "Mostrar % en el icono de la bandeja" },
            ["T_Topmost"]      = new[] { "Sempre no topo", "Always on top", "Siempre visible" },
            ["T_Opacity"]      = new[] { "Opacidade: {0}%", "Opacity: {0}%", "Opacidad: {0}%" },
            ["T_ResetLook"]    = new[] { "Restaurar aparência padrão", "Reset appearance", "Restablecer apariencia" },

            // ---------- Bandeja ----------
            ["T_TrayOpen"]  = new[] { "Abrir", "Open", "Abrir" },
            ["T_TrayClean"] = new[] { "Limpar agora", "Clean now", "Liberar ahora" },
            ["T_TrayGame"]  = new[] { "Modo jogo", "Game mode", "Modo juego" },
            ["T_TrayExit"]  = new[] { "Sair", "Exit", "Salir" },
            ["T_TrayHint"]  = new[] { "Continua rodando na bandeja. Clique direito no ícone para sair.",
                                      "Still running in the tray. Right-click the icon to exit.",
                                      "Sigue ejecutándose en la bandeja. Clic derecho en el icono para salir." },
        };

        public static void Apply(string lang)
        {
            Lang = lang is "en" or "es" ? lang : "pt";
            int i = Index();
            var r = Application.Current.Resources;
            foreach (var kv in D) r[kv.Key] = kv.Value[i];
        }

        public static string T(string key, params object[] args)
        {
            string s = D.TryGetValue(key, out var v) ? v[Index()] : key;
            return args.Length > 0 ? string.Format(s, args) : s;
        }
    }
}
