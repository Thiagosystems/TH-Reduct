using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading;

namespace THReduct
{
    /// <summary>
    /// Modo jogo. Quando um jogo salvo (ou detectado na Steam/Epic/Riot) está aberto:
    ///  • prioridade de CPU alta e prioridade de memória máxima para o jogo;
    ///  • prioridade de memória baixa para os outros apps (o Windows tira RAM deles primeiro);
    ///  • a cada N s esvazia o working set dos outros apps e limpa a standby de baixa prioridade;
    ///  • opcional: plano de energia Alto desempenho, pausar ou fechar apps pesados, limpar ao abrir.
    /// Tudo é desfeito quando o jogo fecha.
    /// </summary>
    public sealed class GameBooster
    {
        const uint MEMORY_PRIORITY_LOW = 2, MEMORY_PRIORITY_NORMAL = 5;

        readonly Settings _s;
        readonly HashSet<int> _lowered = new();
        readonly List<int> _suspended = new();
        int _gamePid = -1;
        string _gameName = "";
        GameProfile? _profile;
        bool _power;
        DateTime _lastTrim = DateTime.MinValue, _lastScan = DateTime.MinValue;

        public string Status { get; private set; } = "";
        public bool Active => _gamePid > 0;
        public string GameName => _gameName;
        public bool IsAuto { get; private set; }

        public event Action<string>? GameStarted;
        public event Action<long>? Cleaned;

        public GameBooster(Settings s) => _s = s;

        public static string Normalize(string name)
        {
            name = Path.GetFileName(name.Trim());
            if (name.EndsWith(".exe", StringComparison.OrdinalIgnoreCase)) name = name[..^4];
            return name;
        }

        /// <summary>Chamar a cada ~1 s, fora da thread da interface.</summary>
        public void Update()
        {
            if (!_s.GameMode)
            {
                if (Active) Stop();
                Status = Loc.T("T_GameOff");
                return;
            }

            if (Active && (!Alive(_gamePid) || !ProfileStillValid())) Stop();

            if (!Active)
            {
                if ((DateTime.Now - _lastScan).TotalSeconds < 2) return;
                _lastScan = DateTime.Now;

                var (pid, profile, auto) = FindGame();
                if (pid <= 0) { Status = Loc.T("T_GameWaiting"); return; }
                try
                {
                    using var p = Process.GetProcessById(pid);
                    Start(p, profile!, auto);
                }
                catch { return; }
            }

            if (_profile != null && (DateTime.Now - _lastTrim).TotalSeconds >= _profile.TrimSeconds)
            {
                LowerOthers();
                TrimOthers();
                _lastTrim = DateTime.Now;
            }
        }

        bool ProfileStillValid()
        {
            if (IsAuto) return _s.AutoDetectGames;
            return _profile != null && _profile.Enabled && _s.Games.Contains(_profile)
                   && Normalize(_profile.Exe).Equals(_gameName, StringComparison.OrdinalIgnoreCase);
        }

        (int Pid, GameProfile? Profile, bool Auto) FindGame()
        {
            foreach (var g in _s.Games.ToArray())
            {
                if (!g.Enabled) continue;
                string exe = Normalize(g.Exe);
                if (exe.Length == 0) continue;
                var ps = Process.GetProcessesByName(exe);
                int pid = ps.Length > 0 ? ps[0].Id : -1;
                foreach (var p in ps) p.Dispose();
                if (pid > 0) return (pid, g, false);
            }

            if (_s.AutoDetectGames)
            {
                foreach (int pid in Native.WindowPids())
                {
                    if (pid <= 4 || pid == Environment.ProcessId) continue;
                    string? path = Native.ProcessPath(pid);
                    if (path != null && GameLibrary.IsGame(path, Path.GetFileNameWithoutExtension(path)))
                        return (pid, _s.AutoProfile, true);
                }
            }
            return (-1, null, false);
        }

        void Start(Process p, GameProfile profile, bool auto)
        {
            _gamePid = p.Id;
            _gameName = p.ProcessName;
            _profile = profile;
            IsAuto = auto;

            try { p.PriorityClass = ProcessPriorityClass.High; } catch { }
            try { SetMemPriority(p.Handle, MEMORY_PRIORITY_NORMAL); } catch { }

            LowerOthers();

            if (profile.PowerPlan)
            {
                PowerPlan.SetHighPerformance();
                _power = true;
            }

            HandleHeavyApps(profile.HeavyAction);

            if (profile.CleanOnStart)
            {
                long freed = MemoryCleaner.Clean(_s);
                Cleaned?.Invoke(freed);
            }
            _lastTrim = DateTime.Now;

            Status = Loc.T("T_GameActive", _gameName);
            GameStarted?.Invoke(_gameName);
        }

        public void Stop()
        {
            if (_gamePid > 0)
            {
                try
                {
                    using var g = Process.GetProcessById(_gamePid);
                    if (!g.HasExited) g.PriorityClass = ProcessPriorityClass.Normal;
                }
                catch { }
            }

            foreach (int pid in _lowered)
            {
                try
                {
                    using var p = Process.GetProcessById(pid);
                    SetMemPriority(p.Handle, MEMORY_PRIORITY_NORMAL);
                }
                catch { }
            }
            _lowered.Clear();

            foreach (int pid in _suspended)
            {
                try { Native.Suspend(pid, false); } catch { }
            }
            _suspended.Clear();

            if (_power)
            {
                PowerPlan.Restore();
                _power = false;
            }

            _gamePid = -1;
            _gameName = "";
            _profile = null;
            IsAuto = false;
        }

        void HandleHeavyApps(int action)
        {
            if (action == 0) return;
            var names = _s.HeavyApps.Split(',', ';')
                          .Select(Normalize)
                          .Where(n => n.Length > 0 && !n.Equals(_gameName, StringComparison.OrdinalIgnoreCase))
                          .Distinct(StringComparer.OrdinalIgnoreCase);

            var toKill = new List<Process>();
            foreach (var name in names)
            {
                foreach (var p in Process.GetProcessesByName(name))
                {
                    try
                    {
                        if (action == 1)
                        {
                            if (Native.Suspend(p.Id, true)) _suspended.Add(p.Id);
                            p.Dispose();
                        }
                        else
                        {
                            p.CloseMainWindow();
                            toKill.Add(p);
                        }
                    }
                    catch { p.Dispose(); }
                }
            }

            if (toKill.Count == 0) return;
            Thread.Sleep(3000); // tempo para fecharem normalmente
            foreach (var p in toKill)
            {
                try { if (!p.HasExited) p.Kill(); } catch { }
                p.Dispose();
            }
        }

        void LowerOthers()
        {
            foreach (var p in Others())
            {
                try
                {
                    if (!_lowered.Contains(p.Id) && SetMemPriority(p.Handle, MEMORY_PRIORITY_LOW))
                        _lowered.Add(p.Id);
                }
                catch { }
                finally { p.Dispose(); }
            }
        }

        void TrimOthers()
        {
            foreach (var p in Others())
            {
                try { if (!_suspended.Contains(p.Id)) Native.EmptyWorkingSet(p.Handle); }
                catch { }
                finally { p.Dispose(); }
            }
            MemoryCleaner.PurgeLowPriorityStandby();
        }

        /// <summary>Processos da sessão do usuário, exceto o jogo e o TH Reduct (serviços ficam de fora).</summary>
        IEnumerable<Process> Others()
        {
            int self = Environment.ProcessId;
            int session = Process.GetCurrentProcess().SessionId;
            foreach (var p in Process.GetProcesses())
            {
                bool skip;
                try { skip = p.Id <= 4 || p.Id == self || p.Id == _gamePid || p.SessionId != session; }
                catch { skip = true; }
                if (skip) { p.Dispose(); continue; }
                yield return p;
            }
        }

        static bool SetMemPriority(IntPtr handle, uint priority)
        {
            var info = new Native.MEMORY_PRIORITY_INFORMATION { MemoryPriority = priority };
            return Native.SetProcessInformation(handle, Native.ProcessMemoryPriority, ref info,
                Marshal.SizeOf<Native.MEMORY_PRIORITY_INFORMATION>());
        }

        static bool Alive(int pid)
        {
            try { using var p = Process.GetProcessById(pid); return !p.HasExited; }
            catch { return false; }
        }

        /// <summary>Apps abertos com janela (para o seletor de jogo).</summary>
        public static List<(string Exe, string Title)> WindowedApps()
        {
            int self = Environment.ProcessId;
            var list = new List<(string, string)>();
            var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (var p in Process.GetProcesses())
            {
                try
                {
                    if (p.Id != self && p.MainWindowHandle != IntPtr.Zero && !string.IsNullOrWhiteSpace(p.MainWindowTitle)
                        && seen.Add(p.ProcessName))
                        list.Add((p.ProcessName, p.MainWindowTitle));
                }
                catch { }
                finally { p.Dispose(); }
            }
            return list.OrderBy(x => x.Item1, StringComparer.OrdinalIgnoreCase).ToList();
        }
    }
}
