using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Threading;
using WF = System.Windows.Forms;

namespace THReduct
{
    public partial class MainWindow : Window
    {
        const int MaxSamples = 300; // 5 min com 1 amostra/s

        readonly Settings _s = Settings.Load();
        readonly DispatcherTimer _timer = new() { Interval = TimeSpan.FromSeconds(1) };
        readonly GameBooster _booster;
        readonly SystemStats _stats = new();
        readonly HotkeyManager _hotkey = new();
        readonly OverlayWindow _overlay = new();
        readonly Queue<double> _samples = new();
        readonly Dictionary<string, DateTime> _procWarned = new(StringComparer.OrdinalIgnoreCase);

        WF.NotifyIcon _tray = null!;
        WF.ToolStripMenuItem _trayOpen = null!, _trayClean = null!, _trayGame = null!, _trayExit = null!;
        Action? _balloonAction;

        GameProfile? _selectedGame; // null = perfil dos jogos detectados automaticamente
        double _targetPct, _shownPct = -1;
        int _lastIconKey = int.MinValue;
        bool? _danger;
        DateTime _lastClean = DateTime.Now, _lastLowWarn = DateTime.MinValue,
                 _lastProcList = DateTime.MinValue, _lastProcAlert = DateTime.MinValue;
        bool _cleaning, _bgBusy, _loading = true, _exiting, _settingsOpen;

        public MainWindow()
        {
            InitializeComponent();
            Icon = IconFactory.LogoSource();

            _booster = new GameBooster(_s);
            _booster.GameStarted += name => Dispatcher.InvokeAsync(() =>
                ShowBalloon(Loc.T("T_GameDetected", name), null));
            _booster.Cleaned += freed => Dispatcher.InvokeAsync(() =>
                AddHistory(freed, "game", _booster.GameName));

            BuildSwatches();
            SetupTray();
            LoadSettingsToUi();
            HookEvents();
            ApplyWindowLook();

            _hotkey.Attach(this);
            _hotkey.Pressed += () => _ = CleanAsync("hotkey");
            ApplyHotkey();

            _timer.Tick += (_, _) => Tick();
            _timer.Start();
            Tick();

            CompositionTarget.Rendering += Animate;
            _loading = false;
        }

        // =====================================================================
        //  Configurações
        // =====================================================================

        void LoadSettingsToUi()
        {
            _loading = true;
            ChkWorkingSet.IsChecked = _s.WorkingSet;
            ChkSystemCache.IsChecked = _s.SystemCache;
            ChkModified.IsChecked = _s.ModifiedList;
            ChkStandby.IsChecked = _s.StandbyList;
            ChkStandbyLow.IsChecked = _s.StandbyLowPriority;

            ChkAuto.IsChecked = _s.AutoClean;
            SldThreshold.Value = _s.AutoThreshold;
            ChkInterval.IsChecked = _s.IntervalClean;
            SldInterval.Value = _s.IntervalMinutes;
            ChkLowRam.IsChecked = _s.LowRamWarn;
            SldLowRam.Value = _s.LowRamThreshold;
            ChkProcAlert.IsChecked = _s.ProcAlert;
            SldProcAlert.Value = _s.ProcAlertMB;

            ChkGameMode.IsChecked = _s.GameMode;
            ChkGameDetect.IsChecked = _s.AutoDetectGames;
            TxtHeavy.Text = _s.HeavyApps;
            _trayGame.Checked = _s.GameMode;

            ChkWidget.IsChecked = _s.WidgetEnabled;
            ChkWidgetGame.IsChecked = _s.WidgetOnlyInGame;
            ChkWidgetExtra.IsChecked = _s.WidgetShowExtra;
            RbCornerTL.IsChecked = _s.WidgetCorner == 0;
            RbCornerTR.IsChecked = _s.WidgetCorner == 1;
            RbCornerBL.IsChecked = _s.WidgetCorner == 2;
            RbCornerBR.IsChecked = _s.WidgetCorner == 3;

            RbDark.IsChecked = _s.Theme == "dark";
            RbBlack.IsChecked = _s.Theme == "black";
            RbLight.IsChecked = _s.Theme == "light";
            TxtColorA.Text = _s.AccentA;
            TxtColorB.Text = _s.AccentB;
            ChkLogoAccent.IsChecked = _s.LogoUseAccent;
            TxtLogoP.Text = _s.LogoPrimary;
            TxtLogoS.Text = _s.LogoSecondary;
            SldScale.Value = _s.Scale;

            RbPt.IsChecked = Loc.Lang == "pt";
            RbEn.IsChecked = Loc.Lang == "en";
            RbEs.IsChecked = Loc.Lang == "es";
            ChkHotkey.IsChecked = _s.HotkeyEnabled;
            TxtHotkey.Text = _s.Hotkey;
            ChkStartup.IsChecked = _s.StartWithWindows;
            ChkStartMin.IsChecked = _s.StartMinimized;
            ChkTrayPct.IsChecked = _s.TrayShowPercent;
            ChkTopmost.IsChecked = _s.Topmost;
            SldOpacity.Value = _s.WindowOpacity;

            BuildGameList();
            LoadGameConfig();
            UpdateLabels();
            RefreshColorUi();
            _loading = false;
        }

        void HookEvents()
        {
            foreach (var cb in new[] { ChkWorkingSet, ChkSystemCache, ChkModified, ChkStandby, ChkStandbyLow,
                                       ChkAuto, ChkInterval, ChkLowRam, ChkProcAlert,
                                       ChkGameMode, ChkGameDetect, ChkGameClean, ChkGamePower,
                                       ChkWidget, ChkWidgetGame, ChkWidgetExtra,
                                       ChkStartMin, ChkTopmost, ChkTrayPct })
            {
                cb.Checked += SettingChanged;
                cb.Unchecked += SettingChanged;
            }
            foreach (var sl in new[] { SldThreshold, SldInterval, SldLowRam, SldProcAlert, SldTrim, SldScale, SldOpacity })
                sl.ValueChanged += (_, _) => SettingChanged(null, null);

            foreach (var rb in new[] { RbHeavyNone, RbHeavyPause, RbHeavyClose })
                rb.Checked += SettingChanged;

            foreach (var rb in new[] { RbCornerTL, RbCornerTR, RbCornerBL, RbCornerBR })
                rb.Checked += Corner_Checked;

            foreach (var rb in new[] { RbDark, RbBlack, RbLight })
                rb.Checked += Theme_Checked;

            foreach (var rb in new[] { RbPt, RbEn, RbEs })
                rb.Checked += Language_Checked;

            ChkLogoAccent.Checked += (_, _) => CommitColors();
            ChkLogoAccent.Unchecked += (_, _) => CommitColors();

            ChkStartup.Checked += (_, _) => StartupChanged(true);
            ChkStartup.Unchecked += (_, _) => StartupChanged(false);

            ChkHotkey.Checked += (_, _) => HotkeyToggled();
            ChkHotkey.Unchecked += (_, _) => HotkeyToggled();
            TxtHotkey.GotKeyboardFocus += (_, _) => { _hotkey.Unregister(); TxtHotkey.Text = Loc.T("T_HotkeyPress"); };
            TxtHotkey.LostKeyboardFocus += (_, _) => { TxtHotkey.Text = _s.Hotkey; ApplyHotkey(); };
            TxtHotkey.PreviewKeyDown += HotkeyBox_KeyDown;

            foreach (var tb in new[] { TxtColorA, TxtColorB, TxtLogoP, TxtLogoS })
            {
                tb.LostFocus += (_, _) => CommitColors();
                tb.KeyDown += (_, e) => { if (e.Key == Key.Enter) CommitColors(); };
            }

            TxtGame.KeyDown += (_, e) => { if (e.Key == Key.Enter) AddGame_Click(this, new RoutedEventArgs()); };
            TxtHeavy.LostFocus += (_, _) => CommitHeavy();
            TxtHeavy.KeyDown += (_, e) => { if (e.Key == Key.Enter) CommitHeavy(); };

            PrevA.MouseLeftButtonUp += (_, _) => PickColor(TxtColorA);
            PrevB.MouseLeftButtonUp += (_, _) => PickColor(TxtColorB);
            PrevLogoP.MouseLeftButtonUp += (_, _) => PickColor(TxtLogoP);
            PrevLogoS.MouseLeftButtonUp += (_, _) => PickColor(TxtLogoS);
        }

        void SettingChanged(object? sender, RoutedEventArgs? e)
        {
            UpdateLabels();
            if (_loading) return;

            _s.WorkingSet = ChkWorkingSet.IsChecked == true;
            _s.SystemCache = ChkSystemCache.IsChecked == true;
            _s.ModifiedList = ChkModified.IsChecked == true;
            _s.StandbyList = ChkStandby.IsChecked == true;
            _s.StandbyLowPriority = ChkStandbyLow.IsChecked == true;

            _s.AutoClean = ChkAuto.IsChecked == true;
            _s.AutoThreshold = (int)SldThreshold.Value;
            _s.IntervalClean = ChkInterval.IsChecked == true;
            _s.IntervalMinutes = (int)SldInterval.Value;
            _s.LowRamWarn = ChkLowRam.IsChecked == true;
            _s.LowRamThreshold = (int)SldLowRam.Value;
            _s.ProcAlert = ChkProcAlert.IsChecked == true;
            _s.ProcAlertMB = (int)SldProcAlert.Value;

            _s.GameMode = ChkGameMode.IsChecked == true;
            _s.AutoDetectGames = ChkGameDetect.IsChecked == true;
            var p = CurrentProfile;
            p.CleanOnStart = ChkGameClean.IsChecked == true;
            p.PowerPlan = ChkGamePower.IsChecked == true;
            p.HeavyAction = RbHeavyClose.IsChecked == true ? 2 : RbHeavyPause.IsChecked == true ? 1 : 0;
            p.TrimSeconds = (int)SldTrim.Value;

            _s.WidgetEnabled = ChkWidget.IsChecked == true;
            _s.WidgetOnlyInGame = ChkWidgetGame.IsChecked == true;
            _s.WidgetShowExtra = ChkWidgetExtra.IsChecked == true;

            _s.Scale = (int)SldScale.Value;
            _s.WindowOpacity = (int)SldOpacity.Value;
            _s.Topmost = ChkTopmost.IsChecked == true;
            _s.StartMinimized = ChkStartMin.IsChecked == true;
            _s.TrayShowPercent = ChkTrayPct.IsChecked == true;
            _s.Save();

            _trayGame.Checked = _s.GameMode;
            ApplyWindowLook();
            _lastIconKey = int.MinValue; // força redesenho do ícone
        }

        void StartupChanged(bool enabled)
        {
            if (_loading) return;
            _s.StartWithWindows = enabled;
            _s.Save();
            Task.Run(() => StartupManager.Set(enabled));
        }

        void UpdateLabels()
        {
            ChkAuto.Content = Loc.T("T_AutoWhen", (int)SldThreshold.Value);
            ChkInterval.Content = Loc.T("T_AutoEvery", (int)SldInterval.Value);
            ChkLowRam.Content = Loc.T("T_LowRam", (int)SldLowRam.Value);
            ChkProcAlert.Content = Loc.T("T_ProcAlertLbl", Fmt((ulong)SldProcAlert.Value * 1024 * 1024));
            SldThreshold.Opacity = ChkAuto.IsChecked == true ? 1 : 0.4;
            SldInterval.Opacity = ChkInterval.IsChecked == true ? 1 : 0.4;
            SldLowRam.Opacity = ChkLowRam.IsChecked == true ? 1 : 0.4;
            SldProcAlert.Opacity = ChkProcAlert.IsChecked == true ? 1 : 0.4;

            LblTrim.Text = Loc.T("T_Trim", (int)SldTrim.Value);
            LblScale.Text = Loc.T("T_Size", (int)SldScale.Value);
            LblOpacity.Text = Loc.T("T_Opacity", (int)SldOpacity.Value);

            TxtLogoP.IsEnabled = PrevLogoP.IsEnabled = ChkLogoAccent.IsChecked != true;
            TxtLogoP.Opacity = PrevLogoP.Opacity = ChkLogoAccent.IsChecked == true ? 0.4 : 1;
            TxtHotkey.Opacity = ChkHotkey.IsChecked == true ? 1 : 0.4;
        }

        void Language_Checked(object sender, RoutedEventArgs e)
        {
            if (_loading) return;
            _s.Language = sender == RbEn ? "en" : sender == RbEs ? "es" : "pt";
            _s.Save();
            Loc.Apply(_s.Language);

            UpdateLabels();
            BuildGameList();
            LoadGameConfig();
            if (PanelHist.Visibility == Visibility.Visible) BuildHistory();
            _lastProcList = DateTime.MinValue;
            UpdateTitle();
            UpdateTrayTexts();
            TxtResult.Text = Loc.T("T_Ready");
        }

        // =====================================================================
        //  Atalho global
        // =====================================================================

        void ApplyHotkey()
        {
            _hotkey.Unregister();
            if (!_s.HotkeyEnabled) return;
            if (!_hotkey.Register(_s.Hotkey))
                ShowBalloon(Loc.T("T_HotkeyFail"), null);
        }

        void HotkeyToggled()
        {
            UpdateLabels();
            if (_loading) return;
            _s.HotkeyEnabled = ChkHotkey.IsChecked == true;
            _s.Save();
            ApplyHotkey();
        }

        void HotkeyBox_KeyDown(object sender, KeyEventArgs e)
        {
            e.Handled = true;
            if (e.Key == Key.Escape) { Keyboard.ClearFocus(); return; }
            string? combo = HotkeyManager.FromKeyEvent(e);
            if (combo == null || !HotkeyManager.TryParse(combo, out _, out _)) return;
            _s.Hotkey = combo;
            _s.Save();
            TxtHotkey.Text = combo;
            Keyboard.ClearFocus(); // LostKeyboardFocus registra o novo atalho
        }

        // =====================================================================
        //  Aparência
        // =====================================================================

        void ApplyWindowLook()
        {
            RootScale.ScaleX = RootScale.ScaleY = _s.Scale / 100.0;
            Opacity = _s.WindowOpacity / 100.0;
            Topmost = _s.Topmost;
        }

        void Theme_Checked(object sender, RoutedEventArgs e)
        {
            if (_loading) return;
            _s.Theme = sender == RbLight ? "light" : sender == RbBlack ? "black" : "dark";
            _s.Save();
            ThemeManager.Apply(_s);
            RefreshColorUi();
            BuildGameList();
        }

        void BuildSwatches()
        {
            foreach (var p in ThemeManager.Presets)
            {
                var b = new Border
                {
                    Width = 24, Height = 24,
                    CornerRadius = new CornerRadius(12),
                    Margin = new Thickness(0, 0, 8, 8),
                    BorderThickness = new Thickness(2),
                    Cursor = Cursors.Hand,
                    ToolTip = p.Name,
                    Tag = p,
                    Background = new LinearGradientBrush(
                        ThemeManager.Parse(p.A, p.A), ThemeManager.Parse(p.B, p.B), new Point(0, 0), new Point(1, 1))
                };
                b.MouseLeftButtonUp += (_, _) =>
                {
                    TxtColorA.Text = p.A;
                    TxtColorB.Text = p.B;
                    CommitColors();
                };
                Swatches.Children.Add(b);
            }
        }

        void CommitColors()
        {
            UpdateLabels();
            if (_loading) return;

            _s.AccentA = Valid(TxtColorA, _s.AccentA);
            _s.AccentB = Valid(TxtColorB, _s.AccentB);
            _s.LogoPrimary = Valid(TxtLogoP, _s.LogoPrimary);
            _s.LogoSecondary = Valid(TxtLogoS, _s.LogoSecondary);
            _s.LogoUseAccent = ChkLogoAccent.IsChecked == true;
            _s.Save();
            ThemeManager.Apply(_s);
            RefreshColorUi();
        }

        static string Valid(TextBox tb, string fallback)
        {
            string v = ThemeManager.TryParse(tb.Text, out var n) ? n : fallback;
            tb.Text = v;
            return v;
        }

        void PickColor(TextBox target)
        {
            var c = ThemeManager.Parse(target.Text, "#FFFFFF");
            using var dlg = new WF.ColorDialog { FullOpen = true, Color = System.Drawing.Color.FromArgb(c.R, c.G, c.B) };
            if (dlg.ShowDialog() != WF.DialogResult.OK) return;
            target.Text = $"#{dlg.Color.R:X2}{dlg.Color.G:X2}{dlg.Color.B:X2}";
            CommitColors();
        }

        void RefreshColorUi()
        {
            var ring = (Brush)FindResource("TextBrush");
            foreach (Border b in Swatches.Children)
            {
                var p = ((string Name, string A, string B))b.Tag;
                bool sel = string.Equals(p.A, _s.AccentA, StringComparison.OrdinalIgnoreCase)
                        && string.Equals(p.B, _s.AccentB, StringComparison.OrdinalIgnoreCase);
                b.BorderBrush = sel ? ring : Brushes.Transparent;
            }
            PrevA.Background = Solid(_s.AccentA);
            PrevB.Background = Solid(_s.AccentB);
            PrevLogoP.Background = Solid(_s.LogoPrimary);
            PrevLogoS.Background = Solid(_s.LogoSecondary);
            _danger = null;
            UpdateGaugeColors();
        }

        static SolidColorBrush Solid(string hex) => new(ThemeManager.Parse(hex, "#FFFFFF"));

        void ResetLook_Click(object sender, RoutedEventArgs e)
        {
            var d = new Settings();
            _s.Theme = d.Theme;
            _s.AccentA = d.AccentA;
            _s.AccentB = d.AccentB;
            _s.LogoUseAccent = d.LogoUseAccent;
            _s.LogoPrimary = d.LogoPrimary;
            _s.LogoSecondary = d.LogoSecondary;
            _s.Scale = d.Scale;
            _s.WindowOpacity = d.WindowOpacity;
            _s.Topmost = d.Topmost;
            _s.Save();
            ThemeManager.Apply(_s);
            LoadSettingsToUi();
            ApplyWindowLook();
        }

        // =====================================================================
        //  Modo jogo
        // =====================================================================

        GameProfile CurrentProfile => _selectedGame ?? _s.AutoProfile;

        void BuildGameList()
        {
            GameList.Children.Clear();
            GameList.Children.Add(GameRow(null));
            foreach (var g in _s.Games) GameList.Children.Add(GameRow(g));
        }

        UIElement GameRow(GameProfile? g)
        {
            bool selected = _selectedGame == g;
            var row = new Border
            {
                CornerRadius = new CornerRadius(6),
                Padding = new Thickness(8, 2, 2, 2),
                Margin = new Thickness(0, 0, 0, 2),
                Cursor = Cursors.Hand,
                MinHeight = 26
            };
            row.SetResourceReference(Border.BackgroundProperty, selected ? "TrackBrush" : "CardBrush");

            var grid = new Grid();
            grid.ColumnDefinitions.Add(new ColumnDefinition());
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            var name = new TextBlock
            {
                Text = g == null ? Loc.T("T_GameAutoRow") : g.Exe + ".exe",
                FontSize = 12,
                VerticalAlignment = VerticalAlignment.Center,
                TextTrimming = TextTrimming.CharacterEllipsis,
                FontStyle = g == null ? FontStyles.Italic : FontStyles.Normal
            };
            name.SetResourceReference(TextBlock.ForegroundProperty, g == null ? "MutedBrush" : "TextBrush");
            grid.Children.Add(name);

            if (g != null)
            {
                var chk = new CheckBox { Style = (Style)FindResource("Toggle"), IsChecked = g.Enabled, Margin = new Thickness(6, 0, 2, 0) };
                chk.Checked += (_, _) => { g.Enabled = true; _s.Save(); };
                chk.Unchecked += (_, _) => { g.Enabled = false; _s.Save(); };
                Grid.SetColumn(chk, 1);
                grid.Children.Add(chk);

                var del = new Button
                {
                    Style = (Style)FindResource("TitleButton"),
                    Content = "",
                    Width = 24, Height = 22,
                    ToolTip = Loc.T("T_GameRemove")
                };
                del.Click += (_, _) =>
                {
                    _s.Games.Remove(g);
                    if (_selectedGame == g) _selectedGame = null;
                    _s.Save();
                    BuildGameList();
                    LoadGameConfig();
                };
                Grid.SetColumn(del, 2);
                grid.Children.Add(del);
            }

            row.Child = grid;
            row.MouseLeftButtonUp += (_, _) =>
            {
                _selectedGame = g;
                BuildGameList();
                LoadGameConfig();
            };
            return row;
        }

        void LoadGameConfig()
        {
            bool wasLoading = _loading;
            _loading = true;
            var p = CurrentProfile;
            LblGameConfig.Text = Loc.T("T_GameConfig", _selectedGame == null ? Loc.T("T_GameAutoRow") : _selectedGame.Exe + ".exe");
            ChkGameClean.IsChecked = p.CleanOnStart;
            ChkGamePower.IsChecked = p.PowerPlan;
            RbHeavyNone.IsChecked = p.HeavyAction == 0;
            RbHeavyPause.IsChecked = p.HeavyAction == 1;
            RbHeavyClose.IsChecked = p.HeavyAction == 2;
            SldTrim.Value = p.TrimSeconds;
            _loading = wasLoading;
            UpdateLabels();
        }

        void AddGame_Click(object sender, RoutedEventArgs e)
        {
            string exe = GameBooster.Normalize(TxtGame.Text);
            if (exe.Length == 0) return;

            var existing = _s.Games.FirstOrDefault(g => g.Exe.Equals(exe, StringComparison.OrdinalIgnoreCase));
            if (existing == null)
            {
                existing = new GameProfile { Exe = exe };
                _s.Games.Add(existing);
            }
            _selectedGame = existing;
            _s.Save();
            TxtGame.Text = "";
            BuildGameList();
            LoadGameConfig();
            if (ChkGameMode.IsChecked != true) ChkGameMode.IsChecked = true;
        }

        void CommitHeavy()
        {
            if (_loading) return;
            _s.HeavyApps = TxtHeavy.Text.Trim();
            _s.Save();
        }

        void PickGame_Click(object sender, RoutedEventArgs e)
        {
            LstGames.Items.Clear();
            foreach (var (exe, title) in GameBooster.WindowedApps())
            {
                var tb = new TextBlock { TextTrimming = TextTrimming.CharacterEllipsis, FontSize = 12 };
                tb.Inlines.Add(new Run(exe + ".exe") { FontWeight = FontWeights.SemiBold });
                var t = new Run("  " + title);
                t.SetResourceReference(TextElement.ForegroundProperty, "MutedBrush");
                tb.Inlines.Add(t);
                LstGames.Items.Add(new ListBoxItem { Content = tb, Tag = exe, ToolTip = title, Style = (Style)FindResource("ListItem") });
            }
            if (LstGames.Items.Count == 0)
                LstGames.Items.Add(new ListBoxItem { Content = Loc.T("T_NoWindows"), IsEnabled = false, Style = (Style)FindResource("ListItem") });
            GamePopup.IsOpen = true;
        }

        void LstGames_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (LstGames.SelectedItem is not ListBoxItem { Tag: string exe }) return;
            GamePopup.IsOpen = false;
            TxtGame.Text = exe;
            AddGame_Click(this, new RoutedEventArgs());
        }

        void UpdateGameUi()
        {
            TxtGameStatus.Text = _booster.Status;
            GameDot.SetResourceReference(Shape.FillProperty, _booster.Active ? "AccentBrush" : "MutedBrush");
            GameBadge.Visibility = _booster.Active ? Visibility.Visible : Visibility.Collapsed;
            TxtGameBadge.Text = _booster.Active ? Loc.T("T_GamePrioritized", _booster.GameName) : "";
        }

        // =====================================================================
        //  Processos
        // =====================================================================

        void BuildProcList(List<(int Pid, string Name, long Bytes)> procs)
        {
            ProcList.Children.Clear();
            long max = procs.Count > 0 ? Math.Max(1, procs[0].Bytes) : 1;

            foreach (var (pid, name, bytes) in procs)
            {
                var grid = new Grid { Margin = new Thickness(0, 0, 4, 7) };
                grid.ColumnDefinitions.Add(new ColumnDefinition());
                grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
                grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

                var left = new StackPanel { VerticalAlignment = VerticalAlignment.Center };
                var tb = new TextBlock { Text = name, FontSize = 12, TextTrimming = TextTrimming.CharacterEllipsis };
                tb.SetResourceReference(TextBlock.ForegroundProperty, "TextBrush");
                var bar = new Border
                {
                    Height = 3,
                    CornerRadius = new CornerRadius(1.5),
                    HorizontalAlignment = HorizontalAlignment.Left,
                    Width = Math.Max(4, 140.0 * bytes / max),
                    Margin = new Thickness(0, 3, 0, 0)
                };
                bar.SetResourceReference(Border.BackgroundProperty, "AccentBrush");
                left.Children.Add(tb);
                left.Children.Add(bar);
                grid.Children.Add(left);

                var mb = new TextBlock { Text = Fmt((ulong)bytes), FontSize = 11.5, Margin = new Thickness(8, 0, 8, 0), VerticalAlignment = VerticalAlignment.Center };
                mb.SetResourceReference(TextBlock.ForegroundProperty, "MutedBrush");
                Grid.SetColumn(mb, 1);
                grid.Children.Add(mb);

                var btn = new Button
                {
                    Style = (Style)FindResource("SecondaryButton"),
                    Height = 22,
                    FontSize = 11,
                    Content = Loc.T("T_ProcCleanBtn")
                };
                btn.Click += async (_, _) =>
                {
                    btn.IsEnabled = false;
                    long freed = await Task.Run(() => MemoryCleaner.CleanProcess(pid));
                    TxtProcStatus.Text = Loc.T("T_ProcFreed", name, Fmt((ulong)freed));
                    AddHistory(freed, "process", name);
                    _lastProcList = DateTime.MinValue;
                };
                Grid.SetColumn(btn, 2);
                grid.Children.Add(btn);

                ProcList.Children.Add(grid);
            }
        }

        void CheckProcAlert(List<(int Pid, string Name, long Bytes)> procs)
        {
            long limit = (long)_s.ProcAlertMB * 1024 * 1024;
            foreach (var (pid, name, bytes) in procs)
            {
                if (bytes < limit) break; // lista está ordenada
                if (_booster.Active && name.Equals(_booster.GameName, StringComparison.OrdinalIgnoreCase)) continue;
                if (_procWarned.TryGetValue(name, out var t) && (DateTime.Now - t).TotalMinutes < 15) continue;

                _procWarned[name] = DateTime.Now;
                ShowBalloon(Loc.T("T_ProcAlertMsg", name, Fmt((ulong)bytes)), async () =>
                {
                    long freed = await Task.Run(() => MemoryCleaner.CleanProcess(pid));
                    AddHistory(freed, "process", name);
                });
                break;
            }
        }

        // =====================================================================
        //  Histórico
        // =====================================================================

        void AddHistory(long freed, string kind, string detail = "")
        {
            _s.History.Insert(0, new HistoryEntry { Time = DateTime.Now, Freed = Math.Max(0, freed), Kind = kind, Detail = detail });
            if (_s.History.Count > 200) _s.History.RemoveRange(200, _s.History.Count - 200);
            _s.Save();
            if (PanelHist.Visibility == Visibility.Visible) BuildHistory();
        }

        void BuildHistory()
        {
            HistList.Children.Clear();
            var today = _s.History.Where(h => h.Time.Date == DateTime.Today).ToList();
            TxtHistSummary.Text = _s.History.Count == 0
                ? Loc.T("T_HistEmpty")
                : Loc.T("T_HistSummary", today.Count, Fmt((ulong)today.Sum(h => h.Freed)), Fmt((ulong)_s.History.Sum(h => h.Freed)));

            foreach (var h in _s.History.Take(100))
            {
                var grid = new Grid { Margin = new Thickness(0, 0, 4, 7) };
                grid.ColumnDefinitions.Add(new ColumnDefinition());
                grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

                var left = new StackPanel();
                var kind = new TextBlock { Text = KindText(h), FontSize = 12, TextTrimming = TextTrimming.CharacterEllipsis };
                kind.SetResourceReference(TextBlock.ForegroundProperty, "TextBrush");
                var time = new TextBlock { Text = h.Time.ToString("dd/MM HH:mm"), FontSize = 10.5 };
                time.SetResourceReference(TextBlock.ForegroundProperty, "MutedBrush");
                left.Children.Add(kind);
                left.Children.Add(time);
                grid.Children.Add(left);

                var freed = new TextBlock { Text = Fmt((ulong)h.Freed), FontSize = 12, FontWeight = FontWeights.SemiBold, VerticalAlignment = VerticalAlignment.Center };
                freed.SetResourceReference(TextBlock.ForegroundProperty, "AccentSolidBrush");
                Grid.SetColumn(freed, 1);
                grid.Children.Add(freed);

                HistList.Children.Add(grid);
            }
        }

        static string KindText(HistoryEntry h) => h.Kind switch
        {
            "auto" => Loc.T("T_KAuto"),
            "game" => Loc.T("T_KGame") + (h.Detail.Length > 0 ? $" · {h.Detail}" : ""),
            "hotkey" => Loc.T("T_KHotkey"),
            "process" => Loc.T("T_KProcess") + (h.Detail.Length > 0 ? $" · {h.Detail}" : ""),
            _ => Loc.T("T_KManual")
        };

        void ClearHistory_Click(object sender, RoutedEventArgs e)
        {
            _s.History.Clear();
            _s.Save();
            BuildHistory();
        }

        // =====================================================================
        //  Widget
        // =====================================================================

        void Corner_Checked(object sender, RoutedEventArgs e)
        {
            if (_loading) return;
            _s.WidgetCorner = sender == RbCornerTL ? 0 : sender == RbCornerBL ? 2 : sender == RbCornerBR ? 3 : 1;
            _s.Save();
            _overlay.SetCorner(_s.WidgetCorner);
        }

        bool OverlayShouldShow() => _s.WidgetEnabled && (!_s.WidgetOnlyInGame || _booster.Active);

        void UpdateOverlay(uint load, bool extra)
        {
            if (!OverlayShouldShow())
            {
                if (_overlay.IsVisible) _overlay.Hide();
                return;
            }

            string? ex = null;
            if (extra)
            {
                string gpu = _stats.Gpu is double g ? $"{g:0}%" : Loc.T("T_NA");
                string temp = _stats.TempC is double t ? $"  ·  {t:0} °C" : "";
                ex = $"CPU {_stats.Cpu:0}%  ·  GPU {gpu}{temp}";
            }
            _overlay.Update((int)load, ex, _booster.Active ? _booster.GameName + ".exe" : null);

            if (!_overlay.IsVisible)
            {
                _overlay.Show();
                _overlay.SetCorner(_s.WidgetCorner);
            }
        }

        // =====================================================================
        //  Navegação
        // =====================================================================

        void Settings_Click(object sender, RoutedEventArgs e)
        {
            _settingsOpen = !_settingsOpen;
            MainView.Visibility = _settingsOpen ? Visibility.Collapsed : Visibility.Visible;
            SettingsView.Visibility = _settingsOpen ? Visibility.Visible : Visibility.Collapsed;
            BtnSettings.Content = _settingsOpen ? "" : "";
            BtnSettings.SetResourceReference(ToolTipProperty, _settingsOpen ? "T_Back" : "T_Settings");
            Wordmark.Visibility = _settingsOpen ? Visibility.Collapsed : Visibility.Visible;
            TxtTitle.Visibility = _settingsOpen ? Visibility.Visible : Visibility.Collapsed;
            UpdateTitle();
            if (!_settingsOpen) _shownPct = -1;
            else _lastProcList = DateTime.MinValue;
        }

        void Tab_Checked(object sender, RoutedEventArgs e)
        {
            if (PanelClean == null) return; // XAML ainda carregando
            PanelClean.Visibility = sender == TabClean ? Visibility.Visible : Visibility.Collapsed;
            PanelAuto.Visibility = sender == TabAuto ? Visibility.Visible : Visibility.Collapsed;
            PanelGame.Visibility = sender == TabGame ? Visibility.Visible : Visibility.Collapsed;
            PanelProc.Visibility = sender == TabProc ? Visibility.Visible : Visibility.Collapsed;
            PanelHist.Visibility = sender == TabHist ? Visibility.Visible : Visibility.Collapsed;
            PanelWidget.Visibility = sender == TabWidget ? Visibility.Visible : Visibility.Collapsed;
            PanelLook.Visibility = sender == TabLook ? Visibility.Visible : Visibility.Collapsed;
            PanelSys.Visibility = sender == TabSys ? Visibility.Visible : Visibility.Collapsed;

            if (sender == TabProc) _lastProcList = DateTime.MinValue;
            if (sender == TabHist) BuildHistory();
            UpdateTitle();
        }

        void UpdateTitle()
        {
            if (TxtTitle == null) return;
            string key = TabAuto.IsChecked == true ? "T_TabAuto"
                       : TabGame.IsChecked == true ? "T_TabGame"
                       : TabProc.IsChecked == true ? "T_TabProc"
                       : TabHist.IsChecked == true ? "T_TabHist"
                       : TabWidget.IsChecked == true ? "T_TabWidget"
                       : TabLook.IsChecked == true ? "T_TabLook"
                       : TabSys.IsChecked == true ? "T_TabSys"
                       : "T_TabClean";
            TxtTitle.Text = Loc.T(key);
        }

        // =====================================================================
        //  Monitoramento
        // =====================================================================

        void Tick()
        {
            var (total, avail, load) = MemoryCleaner.GetStatus();
            ulong used = total - avail;
            _targetPct = load;

            _samples.Enqueue(load);
            while (_samples.Count > MaxSamples) _samples.Dequeue();

            TxtUsed.Text = Fmt(used);
            TxtFree.Text = Fmt(avail);
            TxtTotal.Text = Fmt(total);
            var (cUsed, cLimit) = MemoryCleaner.GetCommit();
            TxtCommit.Text = cLimit > 0 ? Loc.T("T_Virtual", Fmt(cUsed), Fmt(cLimit)) : "";

            if (IsVisible && !_settingsOpen) DrawGraph();
            UpdateTray((int)load, used, total);
            RunBackground(load);

            if (_cleaning) return;
            var now = DateTime.Now;
            var since = now - _lastClean;
            bool autoWillClean = _s.AutoClean && load >= _s.AutoThreshold;

            if (autoWillClean && since.TotalSeconds >= 60)
                _ = CleanAsync("auto");
            else if (_s.IntervalClean && since.TotalMinutes >= _s.IntervalMinutes)
                _ = CleanAsync("auto");
            else if (_s.LowRamWarn && !autoWillClean && load >= _s.LowRamThreshold && (now - _lastLowWarn).TotalMinutes >= 10)
            {
                _lastLowWarn = now;
                ShowBalloon(Loc.T("T_LowRamMsg", load), () => _ = CleanAsync("manual"));
            }
        }

        /// <summary>Trabalho pesado (modo jogo, CPU/GPU, lista de processos) fora da thread da interface.</summary>
        async void RunBackground(uint load)
        {
            if (_bgBusy) return;
            _bgBusy = true;

            var now = DateTime.Now;
            bool extra = OverlayShouldShow() && _s.WidgetShowExtra;
            bool needList = IsVisible && _settingsOpen && TabProc.IsChecked == true && (now - _lastProcList).TotalSeconds >= 3;
            bool needAlert = _s.ProcAlert && (now - _lastProcAlert).TotalSeconds >= 10;
            List<(int Pid, string Name, long Bytes)>? procs = null;

            try
            {
                await Task.Run(() =>
                {
                    _booster.Update();
                    _stats.Update(extra);
                    if (needList || needAlert) procs = MemoryCleaner.TopProcesses(15);
                });
            }
            catch { }
            _bgBusy = false;

            UpdateGameUi();
            UpdateOverlay(load, extra);
            if (procs != null)
            {
                if (needList) { _lastProcList = now; BuildProcList(procs); }
                if (needAlert) { _lastProcAlert = now; CheckProcAlert(procs); }
            }
        }

        void DrawGraph()
        {
            double w = GraphHost.ActualWidth, h = GraphHost.ActualHeight;
            if (w <= 0 || h <= 0 || _samples.Count < 2) return;

            double step = w / (MaxSamples - 1);
            double x0 = w - (_samples.Count - 1) * step;
            double Y(double v) => h - 2 - (h - 4) * v / 100.0;

            var line = new StreamGeometry();
            using (var c = line.Open())
            {
                int i = 0;
                foreach (var v in _samples)
                {
                    var pt = new Point(x0 + i * step, Y(v));
                    if (i == 0) c.BeginFigure(pt, false, false);
                    else c.LineTo(pt, true, true);
                    i++;
                }
            }

            var fill = new StreamGeometry();
            using (var c = fill.Open())
            {
                c.BeginFigure(new Point(x0, h), true, true);
                int i = 0;
                foreach (var v in _samples)
                {
                    c.LineTo(new Point(x0 + i * step, Y(v)), false, true);
                    i++;
                }
                c.LineTo(new Point(w, h), false, false);
            }

            line.Freeze();
            fill.Freeze();
            GraphLine.Data = line;
            GraphFill.Data = fill;
        }

        void Animate(object? sender, EventArgs e)
        {
            if (!IsVisible || _settingsOpen) return;
            if (_shownPct < 0) _shownPct = _targetPct;
            else if (Math.Abs(_targetPct - _shownPct) < 0.05) return;
            else _shownPct += (_targetPct - _shownPct) * 0.12;

            DrawArc(_shownPct);
            TxtPct.Text = $"{Math.Round(_shownPct)}%";
            UpdateGaugeColors();
        }

        void UpdateGaugeColors()
        {
            bool danger = _shownPct >= 85;
            if (_danger == danger) return;
            _danger = danger;
            GaugeArc.SetResourceReference(Shape.StrokeProperty, danger ? "DangerBrush" : "AccentBrush");
            GaugeGlow.Color = danger ? Color.FromRgb(0xEF, 0x44, 0x44) : (Color)FindResource("AccentColorA");
        }

        void DrawArc(double pct)
        {
            const double c = 80, r = 72;
            double a = Math.Clamp(pct, 0.5, 99.99) * 3.6 * Math.PI / 180.0;
            var end = new Point(c + r * Math.Sin(a), c - r * Math.Cos(a));

            var fig = new PathFigure { StartPoint = new Point(c, c - r), IsClosed = false };
            fig.Segments.Add(new ArcSegment(end, new Size(r, r), 0, pct > 50, SweepDirection.Clockwise, true));
            GaugeArc.Data = new PathGeometry(new[] { fig });
        }

        // =====================================================================
        //  Limpeza
        // =====================================================================

        async void Clean_Click(object sender, RoutedEventArgs e) => await CleanAsync("manual");

        async Task CleanAsync(string kind)
        {
            if (_cleaning) return;
            _cleaning = true;
            BtnClean.IsEnabled = false;
            BtnClean.SetResourceReference(ContentProperty, "T_Cleaning");

            try
            {
                long freed = await Task.Run(() => MemoryCleaner.Clean(_s));
                string msg = Loc.T("T_Freed", Fmt((ulong)Math.Max(0, freed)), DateTime.Now.ToString("HH:mm"));
                TxtResult.Text = kind == "auto" ? msg + Loc.T("T_AutoSuffix") : msg;
                AddHistory(freed, kind);
                if (!IsVisible && kind != "auto")
                    ShowBalloon(msg, null);
            }
            catch (Exception ex)
            {
                TxtResult.Text = Loc.T("T_Error", ex.Message);
            }
            finally
            {
                _lastClean = DateTime.Now;
                _cleaning = false;
                BtnClean.IsEnabled = true;
                BtnClean.SetResourceReference(ContentProperty, "T_Clean");
            }
        }

        static string Fmt(ulong bytes)
        {
            double gb = bytes / 1024d / 1024d / 1024d;
            return gb >= 1 ? $"{gb:0.0} GB" : $"{bytes / 1024d / 1024d:0} MB";
        }

        // =====================================================================
        //  Bandeja
        // =====================================================================

        void SetupTray()
        {
            var menu = new WF.ContextMenuStrip();
            _trayOpen = new WF.ToolStripMenuItem("", null, (_, _) => ShowFromTray());
            _trayClean = new WF.ToolStripMenuItem("", null, async (_, _) => await CleanAsync("manual"));
            _trayGame = new WF.ToolStripMenuItem("") { CheckOnClick = true };
            _trayGame.Click += (_, _) => ChkGameMode.IsChecked = _trayGame.Checked;
            _trayExit = new WF.ToolStripMenuItem("", null, (_, _) => ExitApp());
            menu.Items.AddRange(new WF.ToolStripItem[] { _trayOpen, _trayClean, _trayGame, new WF.ToolStripSeparator(), _trayExit });

            _tray = new WF.NotifyIcon { Visible = true, Text = "TH Reduct", ContextMenuStrip = menu };
            _tray.DoubleClick += (_, _) => ShowFromTray();
            _tray.BalloonTipClicked += (_, _) =>
            {
                var action = _balloonAction;
                _balloonAction = null;
                action?.Invoke();
            };
            _tray.BalloonTipClosed += (_, _) => _balloonAction = null;
            UpdateTrayTexts();
        }

        void UpdateTrayTexts()
        {
            _trayOpen.Text = Loc.T("T_TrayOpen");
            _trayClean.Text = Loc.T("T_TrayClean");
            _trayGame.Text = Loc.T("T_TrayGame");
            _trayExit.Text = Loc.T("T_TrayExit");
        }

        void ShowBalloon(string text, Action? onClick)
        {
            _balloonAction = onClick;
            _tray.ShowBalloonTip(4000, "TH Reduct", text, WF.ToolTipIcon.Info);
        }

        void UpdateTray(int pct, ulong used, ulong total)
        {
            string text = $"TH Reduct — {pct}% ({Fmt(used)} / {Fmt(total)})";
            _tray.Text = text.Length > 63 ? text[..63] : text;
            int key = _s.TrayShowPercent ? pct : -1;
            if (key == _lastIconKey) return;
            _lastIconKey = key;
            var old = _tray.Icon;
            _tray.Icon = _s.TrayShowPercent ? IconFactory.Percent(pct) : IconFactory.Logo();
            old?.Dispose();
        }

        void ShowFromTray()
        {
            Show();
            WindowState = WindowState.Normal;
            Activate();
            _shownPct = -1;
        }

        void HideToTray()
        {
            Hide();
            if (!_s.TrayHintShown)
            {
                _s.TrayHintShown = true;
                _s.Save();
                ShowBalloon(Loc.T("T_TrayHint"), null);
            }
        }

        void ExitApp()
        {
            _exiting = true;
            _timer.Stop();
            CompositionTarget.Rendering -= Animate;
            try { _booster.Stop(); } catch { }
            _hotkey.Dispose();
            _overlay.Close();
            _tray.Visible = false;
            _tray.Dispose();
            Application.Current.Shutdown();
        }

        // =====================================================================
        //  Janela
        // =====================================================================

        void TitleBar_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ButtonState == MouseButtonState.Pressed) DragMove();
        }

        void Minimize_Click(object sender, RoutedEventArgs e) => WindowState = WindowState.Minimized;
        void Close_Click(object sender, RoutedEventArgs e) => HideToTray();

        protected override void OnClosing(CancelEventArgs e)
        {
            if (!_exiting) { e.Cancel = true; HideToTray(); }
            base.OnClosing(e);
        }
    }
}
